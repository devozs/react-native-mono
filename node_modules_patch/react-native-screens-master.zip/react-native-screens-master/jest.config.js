module.exports = {
  preset: 'react-native',
  modulePathIgnorePatterns: ['Example'],
};
